package com.elvis.training_with_Java;

public class Account {
    Double vaueOfAllTrades;

    public Double getVaueOfAllTrades() {
        return vaueOfAllTrades;
    }

    public void setVaueOfAllTrades(Double vaueOfAllTrades) {
        this.vaueOfAllTrades = vaueOfAllTrades;
    }
}
